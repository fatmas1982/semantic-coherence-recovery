Experiment: M1_T2_dual_r0_C
Status: complete
Rows: 474/474
Only complete experiments receive performance scores. Numeric labels and rubric are in MANIFEST.json.
Reference columns are archived predictions, not retrained baselines. Generator subgroup differences are descriptive; exclusion changes sample composition.
Easy/hard comparisons may reflect adjudicated-reference noise as well as intrinsic difficulty. Seed/subset repeat variation is not a confidence interval.
T4 labels are the least reproducible reference targets; alpha is not an F1 ceiling.
